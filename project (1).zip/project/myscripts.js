const apiContent = `<div class="d2">
        <div class="header">
          <span class="title">Productivity Status</span>
          <div>
            <button class="shadow-button">
              <img src="icon/document-upload.svg" />
              <span>Export</span>
            </button>
            <button class="shadow-button color-none">
              <img src="icon/max.svg" />
            </button>
          </div>
        </div>
        <hr />
        <div style="font-size: 12; color: #374151">
          <span class="dot"></span>
          <span id="apiName">APC</span>
        </div>
        <div style="width: 100%; display: flex; justify-content: center">
          <img style="width: 90%" src="icon/graph.svg" />
        </div>
      </div>
      <div class="bottom-division">
        <div class="d3">
          <div><span class="title">Get Workorder API</span></div>
          <hr />
          <div
            style="
              display: flex;
              flex-direction: row;
              justify-content: space-around;
              padding: 40px 0 0;
            "
            class="api-workorder"
          >
            <div
              style="display: flex; flex-direction: column; align-items: center"
            >
              <div class="value-font">1234</div>
              <div class="description-font">Next Month Maxima</div>
            </div>
            <div
              style="display: flex; flex-direction: column; align-items: center"
            >
              <div class="value-font">82</div>
              <div class="description-font">MSE</div>
            </div>
            <div
              style="display: flex; flex-direction: column; align-items: center"
            >
              <div class="value-font">1200</div>
              <div class="description-font">Prev Month Acutal</div>
            </div>
          </div>
        </div>
        <div class="d4">
          <div><span class="title">Each Day Forecast</span></div>
          <hr />
          <div class="forecast-list">
            <table class="myTable" id="forecastTable">
              <thead>
                <th>Date</th>
                <th>Forecasted Value</th>
              </thead>
              <tbody></tbody>
            </table>
          </div>
        </div>
      </div>`;

const apiResponse = [
  { name: "Name 1", max: 120 },
  { name: "Name 2", max: 100 },
  { name: "Name 3", max: 2300 },
  { name: "Name 4", max: 122 },
  { name: "Name 5", max: 122 },
  { name: "Name 6", max: 122 },
  { name: "Name 7", max: 122 },
  { name: "Name 8", max: 122 },
  { name: "Name 9", max: 122 },
  { name: "Name 10", max: 122 },
];
const forecastValue = [
  { date: "18-06-2024", forecast: 120 },
  { date: "18-06-2024", forecast: 120 },
  { date: "18-06-2024", forecast: 120 },
  { date: "18-06-2024", forecast: 120 },
  { date: "18-06-2024", forecast: 120 },
  { date: "18-06-2024", forecast: 120 },
  { date: "18-06-2024", forecast: 120 },
  { date: "18-06-2024", forecast: 120 },
  { date: "18-06-2024", forecast: 120 },
];
$(document).ready(function () {
  apiResponse.forEach((name) => {
    $("#myTable tbody").append(
      `<tr> <td>${name.name}</td> <td>${name.max}</td> </tr>`
    );
  });
  $("ul#menuItem li a").click(function () {
    this.classList.add("active-btn");
  });

  $("ul#subAPI li a").click(function () {
    const apiName = this.text;
    console.log(this.text);
    $("#main-content").html(apiContent);
    $("#apiName").html(apiName);
    forecastValue.forEach((name) => {
      $("#forecastTable tbody").append(
        `<tr> <td>${name.date}</td> <td>${name.forecast}</td> </tr>`
      );
    });
  });

  function getQueryParams() {
    var params = {};
    var queryString = window.location.search.substring(1);
    var vars = queryString.split("&");
    for (var i = 0; i < vars.length; i++) {
      var pair = vars[i].split("=");
      if (typeof params[pair[0]] === "undefined") {
        params[pair[0]] = decodeURIComponent(pair[1]);
      } else if (typeof params[pair[0]] === "string") {
        var arr = [params[pair[0]], decodeURIComponent(pair[1])];
        params[pair[0]] = arr;
      } else {
        params[pair[0]].push(decodeURIComponent(pair[1]));
      }
    }
    return params;
  }
  function addProjectName() {
    var params = getQueryParams();
    var page = params.page;
    console.log(page);
    $("#projectName").html(page);
  }
  addProjectName();
});

function seletAndDeselect() {
  var elem = document.getElementById("subAPI");
  if (elem.classList.length && elem.classList.contains("visibale-list")) {
    elem.classList = [];
  } else {
    elem.classList.add("visibale-list");
  }
}
