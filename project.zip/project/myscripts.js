$(document).ready(function () {
  // add API call
  const apiResponse = [
    { name: "Name 1", max: 120 },
    { name: "Name 2", max: 100 },
    { name: "Name 3", max: 2300 },
    { name: "Name 4", max: 122 },
    { name: "Name 5", max: 122 },
    { name: "Name 6", max: 122 },
    { name: "Name 7", max: 122 },
    { name: "Name 8", max: 122 },
    { name: "Name 9", max: 122 },
    { name: "Name 10", max: 122 },
  ];
  apiResponse.forEach((name) => {
    $("#myTable tbody").append(
      `<tr> <td>${name.name}</td> <td>${name.max}</td> </tr>`
    );
  });
  $("ul#menuItem li a").click(function () {
    this.classList.add("active-btn");
  });

  function getQueryParams() {
    var params = {};
    var queryString = window.location.search.substring(1);
    var vars = queryString.split("&");
    for (var i = 0; i < vars.length; i++) {
      var pair = vars[i].split("=");
      if (typeof params[pair[0]] === "undefined") {
        params[pair[0]] = decodeURIComponent(pair[1]);
      } else if (typeof params[pair[0]] === "string") {
        var arr = [params[pair[0]], decodeURIComponent(pair[1])];
        params[pair[0]] = arr;
      } else {
        params[pair[0]].push(decodeURIComponent(pair[1]));
      }
    }
    return params;
  }
  function addProjectName() {
    var params = getQueryParams();
    var page = params.page;
    console.log(page);
    $("#projectName").html(page);
  }
  addProjectName();
});

function seletAndDeselect() {
  var elem = document.getElementById("subAPI");
  if (elem.classList.length && elem.classList.contains("visibale-list")) {
    elem.classList = [];
  } else {
    elem.classList.add("visibale-list");
  }
}
