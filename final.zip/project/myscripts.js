const apiContent = `<div class="d2">
        <div class="header">
          <span class="title">Productivity Status</span>
          <div>
            <button class="shadow-button">
              <img src="icon/document-upload.svg" />
              <span>Export</span>
            </button>
            <button class="shadow-button color-none">
              <img src="icon/max.svg" />
            </button>
          </div>
        </div>
        <hr />
        <div style="font-size: 12; color: #374151">
          <span class="dot"></span>
          <span id="apiName">APC</span>
        </div>
        <div style="width: 100%; display: flex; justify-content: center">
          <img style="width: 90%" src="icon/graph.svg" />
        </div>
      </div>
      <div class="bottom-division">
        <div class="d3">
          <div><span class="title">Get Workorder API</span></div>
          <hr />
          <div
            style="
              display: flex;
              flex-direction: row;
              justify-content: space-around;
              padding: 40px 0 0;
            "
            class="api-workorder"
          >
            <div
              style="display: flex; flex-direction: column; align-items: center"
            >
              <div class="value-font">1234</div>
              <div class="description-font">Next Month Maxima</div>
            </div>
            <div
              style="display: flex; flex-direction: column; align-items: center"
            >
              <div class="value-font">82</div>
              <div class="description-font">MSE</div>
            </div>
            <div
              style="display: flex; flex-direction: column; align-items: center"
            >
              <div class="value-font">1200</div>
              <div class="description-font">Prev Month Acutal</div>
            </div>
          </div>
        </div>
        <div class="d4">
          <div><span class="title">Each Day Forecast</span></div>
          <hr />
          <div class="forecast-list">
            <table class="myTable" id="forecastTable">
              <thead>
                <th>Date</th>
                <th>Forecasted Value</th>
              </thead>
              <tbody></tbody>
            </table>
          </div>
        </div>
      </div>`;
const dashBoard=`      <div class="d2">
        <div class="header">
          <span class="title">Productivity Status</span>
          <div>
            <button class="shadow-button">
              <img style="height: 15px" src="icon/refresh.svg" />
              <span>Refresh</span>
            </button>
            <button class="shadow-button">
              <img src="icon/document-upload.svg" />
              <span>Export</span>
            </button>
            <button class="shadow-button color-none">
              <img src="icon/max.svg" />
            </button>
          </div>
        </div>
        <hr />
        <div style="width: 100%; display: flex; justify-content: center">
          <img style="width: 90%" src="icon/graph.svg" />
        </div>
      </div>
      <div class="bottom-division">
        <div class="d3">
          <div><span class="title">API List</span></div>
          <hr />
          <div class="api-list">
            <ul>
              <li>
                <input type="checkbox" id="api1" /><label for="api1"
                  >API 1</label
                >
              </li>
              <li>
                <input type="checkbox" id="api2" /><label for="api2"
                  >API 2</label
                >
              </li>
              <li>
                <input type="checkbox" id="api3" /><label for="api3"
                  >API 3</label
                >
              </li>
              <li>
                <input type="checkbox" id="api4" /><label for="api4"
                  >API 4</label
                >
              </li>
              <li>
                <input type="checkbox" id="api5" /><label for="api5"
                  >API 5</label
                >
              </li>
              <li>
                <input type="checkbox" id="api6" /><label for="api6"
                  >API 6</label
                >
              </li>
              <li>
                <input type="checkbox" id="api7" /><label for="api7"
                  >API 7</label
                >
              </li>
              <li>
                <input type="checkbox" id="api8" /><label for="api8"
                  >API 8</label
                >
              </li>
              <li>
                <input type="checkbox" id="api9" /><label for="api9"
                  >API 9</label
                >
              </li>
              <li>
                <input type="checkbox" id="api10" /><label for="api10"
                  >API 10</label
                >
              </li>
            </ul>
          </div>
        </div>
        <div class="d4">
          <div><span class="title">Forecast</span></div>
          <hr />
          <div class="forecast-list">
            <table class="myTable" id="myTable">
              <thead>
                <th>Name</th>
                <th>Maxima</th>
              </thead>
              <tbody></tbody>
            </table>
          </div>
        </div>
      </div>`
const apiResponse = [
  { name: "Name 1", max: 120 },
  { name: "Name 2", max: 100 },
  { name: "Name 3", max: 2300 },
  { name: "Name 4", max: 122 },
  { name: "Name 5", max: 122 },
  { name: "Name 6", max: 122 },
  { name: "Name 7", max: 122 },
  { name: "Name 8", max: 122 },
  { name: "Name 9", max: 122 },
  { name: "Name 10", max: 122 },
];
const forecastValue = [
  { date: "18-06-2024", forecast: 120 },
  { date: "18-06-2024", forecast: 120 },
  { date: "18-06-2024", forecast: 120 },
  { date: "18-06-2024", forecast: 120 },
  { date: "18-06-2024", forecast: 120 },
  { date: "18-06-2024", forecast: 120 },
  { date: "18-06-2024", forecast: 120 },
  { date: "18-06-2024", forecast: 120 },
  { date: "18-06-2024", forecast: 120 },
];
$(document).ready(function () {
  function populateDashBoard(){
    $("#main-content").html(dashBoard);
    apiResponse.forEach((name) => {
      $("#myTable tbody").append(
        `<tr> <td>${name.name}</td> <td>${name.max}</td> </tr>`
      );
    });
  }

  populateDashBoard();
  apiResponse.forEach((name) => {
    $("#myTable tbody").append(
      `<tr> <td>${name.name}</td> <td>${name.max}</td> </tr>`
    );
  });
  $("ul#menuItem li a").click(function () {
    this.classList.add("active-btn");
  });

  $("ul#subAPI li a").click(function () {
    const apiName = this.text;
    console.log(this.text);
    //main
    $("#main-content").html(apiContent);
    $("#apiName").html(apiName);
    
    //values
    forecastValue.forEach((name) => {
      $("#forecastTable tbody").append(
        `<tr> <td>${name.date}</td> <td>${name.forecast}</td> </tr>`
      );
    });
  });

  $('#dashboardLi').click(function(){
    populateDashBoard()
  })

  function getQueryParams() {
    var params = {};
    var queryString = window.location.search.substring(1);
    var vars = queryString.split("&");
    for (var i = 0; i < vars.length; i++) {
      var pair = vars[i].split("=");
      if (typeof params[pair[0]] === "undefined") {
        params[pair[0]] = decodeURIComponent(pair[1]);
      } else if (typeof params[pair[0]] === "string") {
        var arr = [params[pair[0]], decodeURIComponent(pair[1])];
        params[pair[0]] = arr;
      } else {
        params[pair[0]].push(decodeURIComponent(pair[1]));
      }
    }
    return params;
  }
  function addProjectName() {
    var params = getQueryParams();
    var page = params.page;
    console.log(page);
    $("#projectName").html(page);
  }
  addProjectName();
});

function seletAndDeselect() {
  var elem = document.getElementById("subAPI");
  if (elem.classList.length && elem.classList.contains("visibale-list")) {
    elem.classList = [];
  } else {
    elem.classList.add("visibale-list");
  }
}
